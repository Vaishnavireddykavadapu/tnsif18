/**
 * 
 */
/**
 * 
 */
module empcrud {
	requires java.sql;
}