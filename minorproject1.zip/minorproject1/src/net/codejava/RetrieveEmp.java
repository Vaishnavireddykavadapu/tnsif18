package net.codejava;
import java.sql.*;

public class RetrieveEmp {

	public static void main(String[] args) {
		String dbURL = "jdbc:mysql://localhost:3306/empdb";
		String username = "root";
		String password = "root";
		try(Connection conn = DriverManager.getConnection(dbURL, username, password))
				{
					String sql = "SELECT * FROM emp";
					Statement statement = conn.createStatement();
					ResultSet result = statement.executeQuery(sql);
					int count = 0;
					while(result.next()) {
						String name = result.getString("empname");
						String address = result.getString("empaddress");
						String output = "Emp #%d: %s - %s";
						System.out.println(String.format(output, ++count, name, address));
					}
					
				}
				catch(SQLException ex) {
					ex.printStackTrace();
				}
		// TODO Auto-generated method stub

	}

	private static String getString(String string) {
		// TODO Auto-generated method stub
		return null;
	}

	

	

}
