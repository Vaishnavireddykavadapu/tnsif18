package net.codejava;
import java.sql.*;

public class InsertEmp {

	public static void main(String[] args) {
		String dbURL = "jdbc:mysql://localhost:3306/empdb";
		String username = "root";
		String password = "root";
		try {
			Connection conn = DriverManager.getConnection(dbURL, username, password);
			String sql = "INSERT INTO Emp(empname, empaddress) VALUES (?, ?)";
			
			PreparedStatement statement = conn.prepareStatement(sql);
			statement.setString(1, "sri");
			statement.setString(2, "Mumbai");
			int rowsInserted = statement.executeUpdate();
			if(rowsInserted > 0) {
				System.out.println("A new user was inserted successfully");
			}
		}
		catch(SQLException ex) {
			ex.printStackTrace();
		}
		
		// TODO Auto-generated method stub

	}

}
